# run the following in Terminal to create a virtual environment named 'ap6_venv'
python3 -m venv ap6_venv


